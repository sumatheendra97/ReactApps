import React from 'react'

function Message() {
  return (
    <div>Bari Ide Agoytu</div>
  )
}

export default Message