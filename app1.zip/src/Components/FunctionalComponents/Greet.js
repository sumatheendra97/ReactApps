function Greet() {
    return (
        <h1>Eno Magane, Chennagidiya</h1>
    )
}

export default Greet;