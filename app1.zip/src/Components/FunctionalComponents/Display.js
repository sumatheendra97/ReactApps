import React from 'react'

const Display = () => {
  return (
    <div>Arrow Nan Magne</div>
  )
}

export default Display