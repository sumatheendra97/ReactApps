import React, { Component } from 'react'

export class StateDemo1 extends Component {
  render() {
    return (
      <div>
        <h1>Welcome {this.state.name}</h1>
        <button onClick={()=>this.changeUserID()}>Login</button>
      </div>
    )
  }

  changeUserID(){
    this.setState({name:"Admin"})
  }

  constructor(props) { 
    super()
    this.state = {
       name:"Guest"
    }
  }
}

export default StateDemo1