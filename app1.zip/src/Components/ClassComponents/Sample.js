import React, { Component } from 'react'
import Message from '../FunctionalComponents/Message'

export class Sample extends Component {
  render() {
    return (
      <div>
        <Message/>
        <h1>Sample Nan Maga</h1>        
      </div>
    )
  }
}

export default Sample