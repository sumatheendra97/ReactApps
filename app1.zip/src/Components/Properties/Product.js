import React from 'react'

function Product(props) {
  return (
    <div>Product Details
    <div>Product id:{props.id}</div>
    <div>Name:{props.Name}</div>
    <div>Price:{props.Price}</div>
    <hr/>
    </div>
  )
}

export default Product
