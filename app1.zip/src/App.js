import logo from './logo.svg';
import './App.css';
import Greet from './Components/FunctionalComponents/Greet';
import Message from './Components/FunctionalComponents/Message';
import Display from './Components/FunctionalComponents/Display';
import Sample from './Components/ClassComponents/Sample';
import Product from './Components/Properties/Product'
import Manava from './Components/ClassComponents/Employee';
import StateDemo1 from './Components/State/StateDemo1';
import StateDemo2 from './Components/State/StateDemo2';

function App() {
  return (
    <div>
      <StateDemo1/>
      <StateDemo2/>
    </div>
    
  );
}

export default App;
